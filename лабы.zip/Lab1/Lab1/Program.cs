﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main_menu()
        {
            Console.WriteLine("выберите решение:");
            Console.WriteLine();
            Console.WriteLine("1. решить");
            Console.WriteLine("2. изменить значения");
            Console.WriteLine("3. выйти");

        }
        static int Main(string[] args)
        {
            Console.WriteLine("Программа для решения квадратного уравнения");
            Console.WriteLine("ax^2+bx+c=0");
            int n = 0;

            kv_equation.kv_equation_edit();
            Console.WriteLine();

            while (n != 3)
            {

                Main_menu();
                n = int.Parse(Console.ReadLine());
                switch (n)
                {
                    case 1:
                        {
                            kv_equation.solv();
                            break;
                        }
                    case 2:
                        {
                            kv_equation.kv_equation_edit();
                        }
                        break;
                    case 3:
                        {
                            Console.WriteLine("до свидания");
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("ошибка");
                        }
                        break;
                }

            }
            return 0;
        }

    }
}
